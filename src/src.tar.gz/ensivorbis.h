#ifndef ENSIVORBIS_H
#define ENSIVORBIS_H

extern struct streamstate *vorbisstrstate;
extern void vorbis2SDL(struct streamstate *s);

#endif
