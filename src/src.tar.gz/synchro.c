#include <pthread.h>
#include "synchro.h"
#include "ensitheora.h"


bool fini;

/* les variables pour la synchro, ici */

int textureDispo = 0;
pthread_mutex_t m, m2, m3;
pthread_cond_t c, c2, c3;
int tailleFenetre = 0;
int texturePrete = 0;

/* l'implantation des fonctions de synchro ici */
void envoiTailleFenetre(th_ycbcr_buffer b) {
  pthread_mutex_lock(&m2);
  windowsx = b[0].width;
  windowsy = b[0].height;
  tailleFenetre = 1;
  pthread_cond_signal(&c2);
  pthread_mutex_unlock(&m2);
}

void attendreTailleFenetre() {
  pthread_mutex_lock(&m2);
  //pthread_cond_init(c,NULL)
  while (tailleFenetre == 0){
  }
  //pthread_cond_destroy(c);
  pthread_mutex_unlock(&m);

}

void signalerFenetreEtTexturePrete() {
  pthread_mutex_lock(&m3);
  texturePrete = 1;
  pthread_cond_signal(&c3);
  pthread_mutex_unlock(&m3);
}

void attendreFenetreTexture() {
  pthread_mutex_lock(&m3);
  while (texturePrete == 0){
    pthread_cond_wait(&c3,&m3);
  }
  pthread_mutex_unlock(&m3);
}

void debutConsommerTexture() {
  pthread_mutex_lock(&m);
  while (textureDispo <= 0){
    pthread_cond_wait(&c,&m);
  }
  textureDispo -=1;
}

void finConsommerTexture() {
  pthread_mutex_unlock(&m);
    pthread_cond_signal(&c);
}


void debutDeposerTexture() {
  pthread_mutex_lock(&m);
  while (textureDispo >= NBTEX){
    pthread_cond_wait(&c,&m);
  }
  textureDispo +=1;
}

void finDeposerTexture() {
  pthread_mutex_unlock(&m);
  pthread_cond_signal(&c);
}
