#ifndef OGGSTREAM_H
#define OGGSTREAM_H

void *vorbisStreamReader(void *arg);
void *theoraStreamReader(void *arg);

#endif
